var searchData=
[
  ['grayscaleclient',['GrayscaleClient',['../classGrayscaleClient.html',1,'']]],
  ['grayscaleinterface',['GrayscaleInterface',['../interfaceGrayscaleInterface.html',1,'']]],
  ['grayscaleserver',['GrayscaleServer',['../classGrayscaleServer.html',1,'']]]
];
