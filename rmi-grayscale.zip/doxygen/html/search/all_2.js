var searchData=
[
  ['splitimage',['splitImage',['../classGrayscaleClient.html#a6d22c0e1ee10ec06dabbd248bf8b10eb',1,'GrayscaleClient']]]
];
